# Programming in Java – Assignment 5 (CO5)

**Student name:** ____________________  
**Register number:** ____________________  
**Java version:** Record the output of `java -version` on your computer (recommended JDK 17+).

This repository is organized by implementation task. Part A design answers and pseudocode are supplied in the written assignment response; Part B Java implementations are in the folders below.

## Folder structure

- `Task01/` – CSV bus-pass store and buffered/unbuffered line counter.
- `Task02/` – unsafe SQL concatenation versus `PreparedStatement` login demonstration.
- `Task03/` – generic `Dao<T,K>` interface, Student model and JDBC implementation.
- `Task04/` – serializable Hostel–Room–Resident object graph; password and live connection are transient.
- `Task05/` – JDBC wallet transfer with commit/rollback.
- `Task06/` – JDBC `PreparedStatement` batch loader (batch size 1,000; one transaction).
- `Task07/` – file-to-database migration, reject report and `DatabaseMetaData` inspection.
- `sql/schema.sql` – MySQL schema for the demonstrations.
- `test-data/damaged-passes.csv` – malformed input examples for migration validation.

## Requirements and database setup

1. Install JDK 17 or later and MySQL 8 (or a compatible MySQL server).
2. Run `sql/schema.sql` in MySQL Workbench or the MySQL command line.
3. Download MySQL Connector/J and add its JAR to the classpath when compiling/running JDBC tasks.
4. Set environment variables before running JDBC programs:
   - Windows CMD: `set DB_URL=jdbc:mysql://localhost:3306/co5_transport` then `set DB_USER=root` and `set DB_PASSWORD=your_password`.
   - PowerShell: `$env:DB_URL="jdbc:mysql://localhost:3306/co5_transport"` and similarly set `DB_USER` and `DB_PASSWORD`.

Never commit real database passwords. Use a local test database only.

## Compile and run

Open a terminal in the relevant task folder. For non-database tasks:

```bash
javac PassStore.java LineCounter.java
java PassStore
java LineCounter path/to/attendance.log
```

For JDBC tasks, include Connector/J (replace the JAR path as appropriate):

```bash
javac -cp .;C:\path\mysql-connector-j.jar LoginDemo.java
java -cp .;C:\path\mysql-connector-j.jar LoginDemo
```

On macOS/Linux, use `:` rather than `;` in the classpath. Compile `StudentDao.java` together with `Dao.java` and `Student.java`. Compile `MigrateAndInspect.java` with `../Task06/PassLoader.java` on the classpath/source path, or compile the task folders together.

## Expected checks

- `Task01/PassStore`: prints the P1003 record and `null` for P1002 because the damaged two-field row is skipped.
- `Task01/LineCounter`: both methods should return the same line count; timings depend on disk, JVM warm-up, OS cache and file size.
- `Task02/LoginDemo`: with the seeded test user, the injection-style password ` ' OR '1'='1 ` may make the unsafe query return true, while the prepared query treats it as a literal password and rejects it. Exact behavior depends on the input and database contents.
- `Task04/Hostel`: serializes and reads the object graph; password and connection are not serialized. Do not use Java serialization for untrusted files.
- `Task05/WalletTransfer`: call `WalletTransfer.transfer(connection, 1, 2, new BigDecimal("500.00"))`; verify both balances before and after.
- `Task06/PassLoader`: run with argument `1000`, `10000`, or `100000`; the table must be cleared between repeated trials if comparing equal starting conditions.
- `Task07/MigrateAndInspect`: run with `test-data/damaged-passes.csv` after schema setup. The valid rows are migrated and malformed rows are written to `rejected-records.txt`.

## Measurement and evidence to collect yourself

The assignment explicitly requires measured values and execution screenshots. Do not copy fabricated timings. For B1, create exact 1 MB, 10 MB and 50 MB log files and record unbuffered/buffered milliseconds in a table. For growth tests, generate 1,000, 10,000 and 100,000 passes and time successful and unsuccessful searches. For B3, compare Statement, PreparedStatement and PreparedStatement batches at 1,000, 10,000 and 100,000 rows; run multiple trials and record averages. Compare auto-commit and one transaction, including a controlled failure halfway through. Save terminal output and database SELECT/metadata screenshots in the corresponding task folder.

## GitHub submission workflow

Create repository `CSA09-<RegisterNumber>-Assignment5`. Add your name, register number, actual Java version, screenshots, measured tables and written Part A answers. Make at least one meaningful commit per task (do not upload everything in one final commit). Share the repository with faculty and paste the working URL on the assignment cover page.

## Important implementation notes

- The simple Task01 CSV example rejects commas/newlines in fields. A production CSV parser should support quoting/escaping, and an atomic temp-file + rename strategy or journal is safer against interrupted writes.
- `Task01/LineCounter` demonstrates byte-at-a-time versus buffered character reading; OS/JVM caching affects measured timings.
- `Task02` intentionally includes an unsafe query for a controlled local demonstration only. Never use it in a real application. Real systems should store salted password hashes, not plaintext passwords.
- Task06 commits the entire load as one transaction. A failed row causes rollback of all rows in that call.
- Task07 validates malformed records before insertion. Database failures are rolled back; the reject report records validation failures. Review the report and database state after each run.
