import java.sql.*; import java.util.*;

public class StudentDao implements Dao<Student, Integer> {
    private final Connection con;
    public StudentDao(Connection con){this.con=con;}
    public Integer insert(Student s) throws SQLException {
        String q="INSERT INTO student(reg_no,name,email) VALUES(?,?,?)";
        try(PreparedStatement p=con.prepareStatement(q,Statement.RETURN_GENERATED_KEYS)){
            p.setString(1,s.getRegNo());p.setString(2,s.getName());p.setString(3,s.getEmail());p.executeUpdate();
            try(ResultSet k=p.getGeneratedKeys()){if(k.next())return k.getInt(1);}
        } return -1;
    }
    public Optional<Student> findById(Integer id) throws SQLException {
        try(PreparedStatement p=con.prepareStatement("SELECT student_id,reg_no,name,email FROM student WHERE student_id=?")){
            p.setInt(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}
        }
    }
    public List<Student> findAll() throws SQLException {
        List<Student> out=new ArrayList<>();try(PreparedStatement p=con.prepareStatement("SELECT student_id,reg_no,name,email FROM student");ResultSet r=p.executeQuery()){
            while(r.next())out.add(map(r));}return out;
    }
    public boolean update(Student s) throws SQLException {
        try(PreparedStatement p=con.prepareStatement("UPDATE student SET reg_no=?,name=?,email=? WHERE student_id=?")){
            p.setString(1,s.getRegNo());p.setString(2,s.getName());p.setString(3,s.getEmail());p.setInt(4,s.getStudentId());return p.executeUpdate()==1;}
    }
    public boolean delete(Integer id) throws SQLException {
        try(PreparedStatement p=con.prepareStatement("DELETE FROM student WHERE student_id=?")){p.setInt(1,id);return p.executeUpdate()==1;}
    }
    private Student map(ResultSet r)throws SQLException{return new Student(r.getInt("student_id"),r.getString("reg_no"),r.getString("name"),r.getString("email"));}
}
