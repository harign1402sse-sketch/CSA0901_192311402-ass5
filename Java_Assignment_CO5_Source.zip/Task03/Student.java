public class Student {
    private final int studentId; private final String regNo; private final String name; private final String email;
    public Student(int studentId, String regNo, String name, String email) {
        this.studentId=studentId; this.regNo=regNo; this.name=name; this.email=email;
    }
    public int getStudentId(){return studentId;} public String getRegNo(){return regNo;}
    public String getName(){return name;} public String getEmail(){return email;}
    @Override public String toString(){return studentId+" | "+regNo+" | "+name+" | "+email;}
}
