CREATE DATABASE IF NOT EXISTS co5_transport;
USE co5_transport;

CREATE TABLE IF NOT EXISTS bus_pass (
  pass_id VARCHAR(20) PRIMARY KEY,
  reg_no VARCHAR(20) NOT NULL,
  name VARCHAR(100) NOT NULL,
  route_no INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  INDEX idx_bus_pass_route (route_no),
  INDEX idx_bus_pass_reg (reg_no)
);

CREATE TABLE IF NOT EXISTS app_user (
  user_id VARCHAR(50) PRIMARY KEY,
  password VARCHAR(255) NOT NULL
);
INSERT IGNORE INTO app_user(user_id,password) VALUES ('student1','pass123');

CREATE TABLE IF NOT EXISTS wallet (
  wallet_id BIGINT PRIMARY KEY,
  balance DECIMAL(12,2) NOT NULL CHECK (balance >= 0)
);
INSERT IGNORE INTO wallet(wallet_id,balance) VALUES (1,2000.00),(2,1000.00);

CREATE TABLE IF NOT EXISTS student (
  student_id INT AUTO_INCREMENT PRIMARY KEY,
  reg_no VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(120) NOT NULL
);
