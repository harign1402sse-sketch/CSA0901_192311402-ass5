import java.io.*;
import java.nio.file.*;

public class LineCounter {
    public static long countUnbuffered(Path p) throws IOException {
        long lines = 0; boolean hasData = false; int b;
        try (InputStream in = new FileInputStream(p.toFile())) {
            while ((b = in.read()) != -1) { hasData = true; if (b == '\n') lines++; }
        }
        return lines + (hasData && Files.size(p) > 0 && !endsWithNewline(p) ? 1 : 0);
    }
    private static boolean endsWithNewline(Path p) throws IOException {
        long size = Files.size(p); if (size == 0) return true;
        try (RandomAccessFile f = new RandomAccessFile(p.toFile(), "r")) { f.seek(size - 1); return f.read() == '\n'; }
    }
    public static long countBuffered(Path p) throws IOException {
        long lines = 0; boolean hasData = false; int ch;
        try (BufferedReader r = Files.newBufferedReader(p)) {
            while ((ch = r.read()) != -1) { hasData = true; if (ch == '\n') lines++; }
        }
        return lines + (hasData && !endsWithNewline(p) ? 1 : 0);
    }
    public static void main(String[] args) throws Exception {
        if (args.length != 1) { System.out.println("Usage: java LineCounter <file>"); return; }
        Path p = Path.of(args[0]);
        long t1 = System.nanoTime(), a = countUnbuffered(p), t2 = System.nanoTime();
        long b = countBuffered(p), t3 = System.nanoTime();
        System.out.printf("Unbuffered: %d lines, %.3f ms%n", a, (t2-t1)/1e6);
        System.out.printf("Buffered:   %d lines, %.3f ms%n", b, (t3-t2)/1e6);
    }
}
