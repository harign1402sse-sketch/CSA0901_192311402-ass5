import java.nio.file.*;

public class PassSearchBenchmark {
    public static void main(String[] args) throws Exception {
        int[] sizes={1000,10000,100000};
        for(int size:sizes){
            Path p=Files.createTempFile("pass-search-", ".csv"); PassStore store=new PassStore(p);
            for(int i=1;i<=size;i++)store.add("P"+i,"REG"+i,"Student"+i,i%20,4500.0);
            long start=System.nanoTime(); String[] found=store.find("P"+size); long end=System.nanoTime();
            System.out.printf("records=%d found=%s time=%.3f ms%n",size,found!=null,(end-start)/1e6);
            Files.deleteIfExists(p);
        }
    }
}
