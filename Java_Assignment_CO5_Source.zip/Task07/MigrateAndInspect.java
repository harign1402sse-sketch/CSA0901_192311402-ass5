import java.io.*; import java.nio.file.*; import java.sql.*; import java.util.*;

public class MigrateAndInspect {
    public static void migrate(Path file, Connection con, Path rejects) throws Exception {
        List<String[]> good=new ArrayList<>(); List<String> bad=new ArrayList<>(); int lineNo=0;
        try(BufferedReader r=Files.newBufferedReader(file)){String line;while((line=r.readLine())!=null){lineNo++;String[] f=line.split(",",-1);
            try{if(f.length!=5)throw new IllegalArgumentException("expected 5 fields");Integer.parseInt(f[3]);double amount=Double.parseDouble(f[4]);if(amount<0)throw new IllegalArgumentException("negative amount");good.add(f);}
            catch(RuntimeException e){bad.add("line "+lineNo+": "+e.getMessage()+" | "+line);}
        }}
        try{int loaded=PassLoader.loadAll(con,good);System.out.println("Migrated rows: "+loaded);}
        catch(SQLException e){bad.add("DATABASE BATCH FAILED: "+e.getMessage());throw e;}
        Files.write(rejects,bad,StandardOpenOption.CREATE,StandardOpenOption.TRUNCATE_EXISTING);
        System.out.println("Rejected rows: "+bad.size()+" (report: "+rejects+")");
    }
    public static void inspect(Connection con)throws SQLException{
        DatabaseMetaData m=con.getMetaData();System.out.println("Database: "+m.getDatabaseProductName());
        System.out.println("Driver: "+m.getDriverName()+" "+m.getDriverVersion());
        try(ResultSet t=m.getTables(con.getCatalog(),null,"%",new String[]{"TABLE"})){
            System.out.println("Tables:");while(t.next())System.out.println(" - "+t.getString("TABLE_NAME"));
        }
    }
    public static void main(String[] args)throws Exception{
        if(args.length<1){System.out.println("Usage: java MigrateAndInspect <input.csv>");return;}
        try(Connection c=DriverManager.getConnection(System.getenv("DB_URL"),System.getenv("DB_USER"),System.getenv("DB_PASSWORD"))){
            migrate(Path.of(args[0]),c,Path.of("rejected-records.txt"));inspect(c);
        }
    }
}
