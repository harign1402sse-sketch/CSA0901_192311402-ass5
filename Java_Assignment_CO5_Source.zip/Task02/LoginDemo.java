import java.sql.*;

public class LoginDemo {
    private static Connection connect() throws SQLException {
        return DriverManager.getConnection(System.getenv("DB_URL"), System.getenv("DB_USER"), System.getenv("DB_PASSWORD"));
    }
    public static boolean unsafeLogin(String id, String pwd) throws SQLException {
        String sql = "SELECT COUNT(*) FROM app_user WHERE user_id='" + id + "' AND password='" + pwd + "'";
        try (Connection c = connect(); Statement st = c.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            return rs.next() && rs.getInt(1) > 0;
        }
    }
    public static boolean safeLogin(String id, String pwd) throws SQLException {
        String sql = "SELECT COUNT(*) FROM app_user WHERE user_id=? AND password=?";
        try (Connection c = connect(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, id); ps.setString(2, pwd);
            try (ResultSet rs = ps.executeQuery()) { return rs.next() && rs.getInt(1) > 0; }
        }
    }
    public static void main(String[] args) throws Exception {
        String id = args.length > 0 ? args[0] : "no-such-user";
        String pwd = args.length > 1 ? args[1] : "' OR '1'='1";
        System.out.println("Unsafe login accepted: " + unsafeLogin(id, pwd));
        System.out.println("PreparedStatement accepted: " + safeLogin(id, pwd));
    }
}
