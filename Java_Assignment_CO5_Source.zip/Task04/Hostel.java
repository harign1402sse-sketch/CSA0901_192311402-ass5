import java.io.*; import java.util.*;

public class Hostel implements Serializable {
    private static final long serialVersionUID = 1L;
    private final String hostelName; private final List<Room> rooms = new ArrayList<>();
    public Hostel(String name){hostelName=name;} public void addRoom(Room r){rooms.add(r);}
    public String toString(){return hostelName+" rooms="+rooms;}
    public static void main(String[] args) throws Exception {
        Hostel h=new Hostel("SIMATS Hostel"); Room room=new Room("A-101");
        room.addResident(new Resident("Arun","192311001","secret","9876543210")); h.addRoom(room);
        try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream("hostel.ser"))){out.writeObject(h);}
        try(ObjectInputStream in=new ObjectInputStream(new FileInputStream("hostel.ser"))){System.out.println(in.readObject());}
    }
}
class Room implements Serializable {
    private static final long serialVersionUID=1L; private final String roomNo; private final List<Resident> residents=new ArrayList<>();
    Room(String roomNo){this.roomNo=roomNo;} void addResident(Resident r){residents.add(r);}
    public String toString(){return roomNo+" "+residents;}
}
class Resident implements Serializable {
    private static final long serialVersionUID=1L;
    private final String name, registerNo; private transient String password;
    private final String phoneNumber; // added field: old streams deserialize it as null
    private transient Object databaseConnection; // live JDBC Connection must never be serialized
    Resident(String n,String r,String p,String phone){name=n;registerNo=r;password=p;phoneNumber=phone;}
    public String toString(){return name+"("+registerNo+", phone="+phoneNumber+")";}
}
