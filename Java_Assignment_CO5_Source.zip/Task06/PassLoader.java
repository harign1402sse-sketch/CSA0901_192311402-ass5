import java.sql.*; import java.util.*;

public class PassLoader {
    /** One transaction; JDBC batches are flushed every 1,000 rows. */
    public static int loadAll(Connection con, List<String[]> passes) throws SQLException {
        String sql="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)";
        boolean old=con.getAutoCommit(); con.setAutoCommit(false);
        try(PreparedStatement ps=con.prepareStatement(sql)){
            int n=0, pending=0;
            for(String[] p:passes){
                if(p.length!=5)throw new IllegalArgumentException("Each pass must contain five fields");
                ps.setString(1,p[0]);ps.setString(2,p[1]);ps.setString(3,p[2]);
                ps.setInt(4,Integer.parseInt(p[3]));ps.setDouble(5,Double.parseDouble(p[4]));
                ps.addBatch(); n++; pending++;
                if(pending==1000){ps.executeBatch();ps.clearBatch();pending=0;}
            }
            if(pending>0)ps.executeBatch();
            con.commit(); return n;
        }catch(SQLException|RuntimeException e){try{con.rollback();}catch(SQLException rb){e.addSuppressed(rb);}throw e;}
        finally{con.setAutoCommit(old);}
    }
    public static List<String[]> generate(int count){
        List<String[]> a=new ArrayList<>(count);
        for(int i=1;i<=count;i++)a.add(new String[]{"P"+i,"REG"+i,"Student"+i,Integer.toString((i%20)+1),"4500.00"});
        return a;
    }
    public static void main(String[] args)throws Exception{
        String url=System.getenv("DB_URL"),user=System.getenv("DB_USER"),pass=System.getenv("DB_PASSWORD");
        int count=args.length==0?1000:Integer.parseInt(args[0]);
        try(Connection c=DriverManager.getConnection(url,user,pass)){
            long start=System.nanoTime(); int n=loadAll(c,generate(count));
            System.out.printf("Committed %d rows in %.3f ms%n",n,(System.nanoTime()-start)/1e6);
        }
    }
}
