import java.sql.*; import java.util.*;

/** Controlled comparison harness. Clear bus_pass before each trial. */
public class InsertBenchmark {
    private static final String SQL="INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES('%s','%s','%s',%d,%.2f)";
    private static void clear(Connection c)throws SQLException{try(Statement s=c.createStatement()){s.executeUpdate("DELETE FROM bus_pass");}}
    private static long statement(Connection c,List<String[]> rows)throws SQLException{
        clear(c);long t=System.nanoTime();try(Statement s=c.createStatement()){
            for(String[] p:rows)s.executeUpdate(String.format(Locale.ROOT,SQL,p[0],p[1],p[2],Integer.parseInt(p[3]),Double.parseDouble(p[4])));
        }return System.nanoTime()-t;
    }
    private static long prepared(Connection c,List<String[]> rows)throws SQLException{
        clear(c);long t=System.nanoTime();try(PreparedStatement p=c.prepareStatement("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)")){
            for(String[] a:rows){bind(p,a);p.executeUpdate();}
        }return System.nanoTime()-t;
    }
    private static long batch(Connection c,List<String[]> rows,boolean transaction)throws SQLException{
        clear(c);boolean old=c.getAutoCommit();if(transaction)c.setAutoCommit(false);long t=System.nanoTime();
        try(PreparedStatement p=c.prepareStatement("INSERT INTO bus_pass(pass_id,reg_no,name,route_no,amount) VALUES(?,?,?,?,?)")){
            int n=0;for(String[] a:rows){bind(p,a);p.addBatch();if(++n%1000==0){p.executeBatch();p.clearBatch();}}
            p.executeBatch();if(transaction)c.commit();
        }catch(SQLException e){if(transaction)c.rollback();throw e;}finally{if(transaction)c.setAutoCommit(old);}
        return System.nanoTime()-t;
    }
    private static void bind(PreparedStatement p,String[] a)throws SQLException{
        p.setString(1,a[0]);p.setString(2,a[1]);p.setString(3,a[2]);p.setInt(4,Integer.parseInt(a[3]));p.setDouble(5,Double.parseDouble(a[4]));
    }
    private static void metadata(Connection c)throws SQLException{
        try(Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT * FROM bus_pass LIMIT 1")){
            ResultSetMetaData m=r.getMetaData();for(int i=1;i<=m.getColumnCount();i++)System.out.println(m.getColumnName(i)+" | "+m.getColumnTypeName(i));
        }
    }
    public static void main(String[] args)throws Exception{
        try(Connection c=DriverManager.getConnection(System.getenv("DB_URL"),System.getenv("DB_USER"),System.getenv("DB_PASSWORD"))){
            for(int n:new int[]{10,1000,10000,100000}){List<String[]> rows=PassLoader.generate(n);
                System.out.printf("n=%d Statement %.3f ms%n",n,statement(c,rows)/1e6);
                System.out.printf("n=%d PreparedStatement %.3f ms%n",n,prepared(c,rows)/1e6);
                System.out.printf("n=%d Batch+transaction %.3f ms%n",n,batch(c,rows,true)/1e6);
                if(n==10)metadata(c);
            }
        }
    }
}
