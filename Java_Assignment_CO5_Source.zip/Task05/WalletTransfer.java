import java.math.BigDecimal; import java.sql.*;

public class WalletTransfer {
    public static void transfer(Connection con, long fromId, long toId, BigDecimal amount) throws SQLException {
        if(amount.signum()<=0) throw new IllegalArgumentException("Amount must be positive");
        boolean old=con.getAutoCommit(); con.setAutoCommit(false);
        try {
            try(PreparedStatement debit=con.prepareStatement("UPDATE wallet SET balance=balance-? WHERE wallet_id=? AND balance>=?")){
                debit.setBigDecimal(1,amount);debit.setLong(2,fromId);debit.setBigDecimal(3,amount);
                if(debit.executeUpdate()!=1)throw new SQLException("Insufficient funds or source wallet missing");
            }
            try(PreparedStatement credit=con.prepareStatement("UPDATE wallet SET balance=balance+? WHERE wallet_id=?")){
                credit.setBigDecimal(1,amount);credit.setLong(2,toId);
                if(credit.executeUpdate()!=1)throw new SQLException("Destination wallet missing");
            }
            con.commit();
        } catch(SQLException|RuntimeException e){try{con.rollback();}catch(SQLException rollback){e.addSuppressed(rollback);}throw e;}
        finally{con.setAutoCommit(old);}
    }
}
